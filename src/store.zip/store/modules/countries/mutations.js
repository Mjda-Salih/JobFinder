export default {
    SET_COUNTRIES(state, data){
        state.countries = data
    }
}